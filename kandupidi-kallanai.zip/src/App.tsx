import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { categories } from './words';
import { Users, UserPlus, Play, Eye, Timer, Trophy, RotateCcw, ShieldAlert, X, ChevronRight, BookOpen, Check } from 'lucide-react';

type GameState = 'mainmenu' | 'setup' | 'reveal' | 'discuss' | 'result';

export default function App() {
  const [gameState, setGameState] = useState<GameState>('mainmenu');
  const [players, setPlayers] = useState<string[]>(['Player 1', 'Player 2', 'Player 3']);
  const [newPlayerName, setNewPlayerName] = useState('');
  const [selectedCategories, setSelectedCategories] = useState<string[]>(categories.map(c => c.name));
  
  const [imposterIndex, setImposterIndex] = useState(-1);
  const [currentCategory, setCurrentCategory] = useState('');
  const [currentWord, setCurrentWord] = useState('');
  
  const [revealIndex, setRevealIndex] = useState(0);
  const [isRevealed, setIsRevealed] = useState(false);
  
  const [timeLeft, setTimeLeft] = useState(300); // 5 mins
  const [isTimerRunning, setIsTimerRunning] = useState(false);

  useEffect(() => {
    let timer: number;
    if (gameState === 'discuss' && isTimerRunning && timeLeft > 0) {
      timer = window.setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [gameState, isTimerRunning, timeLeft]);

  const addPlayer = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPlayerName.trim() && players.length < 15) {
      setPlayers([...players, newPlayerName.trim()]);
      setNewPlayerName('');
    }
  };

  const removePlayer = (index: number) => {
    if (players.length > 3) {
      setPlayers(players.filter((_, i) => i !== index));
    }
  };

  const toggleCategory = (catName: string) => {
    if (selectedCategories.includes(catName)) {
      if (selectedCategories.length > 1) {
        setSelectedCategories(selectedCategories.filter(c => c !== catName));
      }
    } else {
      setSelectedCategories([...selectedCategories, catName]);
    }
  };

  const startGame = () => {
    if (players.length < 3 || selectedCategories.length === 0) return;
    
    // Pick random category from selected ones
    const activeCategories = categories.filter(c => selectedCategories.includes(c.name));
    const randomCategory = activeCategories[Math.floor(Math.random() * activeCategories.length)];
    const randomWord = randomCategory.words[Math.floor(Math.random() * randomCategory.words.length)];
    
    // Pick random imposter
    const randomImposter = Math.floor(Math.random() * players.length);
    
    setCurrentCategory(randomCategory.name);
    setCurrentWord(randomWord);
    setImposterIndex(randomImposter);
    
    setRevealIndex(0);
    setIsRevealed(false);
    setGameState('reveal');
  };

  const nextReveal = () => {
    if (revealIndex < players.length - 1) {
      setRevealIndex(revealIndex + 1);
      setIsRevealed(false);
    } else {
      setGameState('discuss');
      setTimeLeft(players.length * 60); // 1 min per player
      setIsTimerRunning(true);
    }
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const resetGame = () => {
    setGameState('setup');
    setIsTimerRunning(false);
  };

  return (
    <div className="min-h-screen bg-amber-50 text-slate-800 font-sans selection:bg-amber-200">
      <header className="bg-amber-500 text-white p-4 shadow-md sticky top-0 z-10">
        <div className="max-w-md mx-auto flex items-center justify-center gap-2">
          <ShieldAlert className="w-6 h-6" />
          <h1 className="text-xl font-bold tracking-wide">Find the Imposter</h1>
        </div>
      </header>

      <main className="max-w-md mx-auto p-4 pb-24">
        <AnimatePresence mode="wait">
          {gameState === 'mainmenu' && (
            <motion.div
              key="mainmenu"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              className="flex flex-col items-center justify-center min-h-[70vh] space-y-8 text-center"
            >
              <div className="space-y-4">
                <ShieldAlert className="w-24 h-24 text-amber-500 mx-auto" />
                <h1 className="text-5xl font-black text-slate-800 tracking-tight">Imposter</h1>
                <h2 className="text-2xl font-bold text-amber-600">கண்டுபிடிடா கள்ளனை!</h2>
              </div>
              
              <div className="bg-white p-6 rounded-3xl shadow-sm border border-amber-100 w-full max-w-sm space-y-4 text-left">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <span className="text-slate-500 font-medium">Word Language</span>
                  <span className="font-bold text-slate-800">Tamil</span>
                </div>
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <span className="text-slate-500 font-medium">Categories</span>
                  <span className="font-bold text-slate-800">{categories.length} Total</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 font-medium">Players</span>
                  <span className="font-bold text-slate-800">3 - 15</span>
                </div>
              </div>

              <button
                onClick={() => setGameState('setup')}
                className="w-full max-w-sm bg-amber-500 text-white py-4 rounded-2xl font-bold text-xl shadow-lg shadow-amber-500/30 hover:bg-amber-600 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
              >
                <Play className="w-6 h-6 fill-current" />
                Play Now
              </button>
            </motion.div>
          )}

          {gameState === 'setup' && (
            <motion.div
              key="setup"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-amber-100">
                <h2 className="text-lg font-semibold mb-4 flex items-center gap-2 text-amber-900">
                  <Users className="w-5 h-5" />
                  Players ({players.length})
                </h2>
                
                <form onSubmit={addPlayer} className="flex gap-2 mb-4">
                  <input
                    type="text"
                    value={newPlayerName}
                    onChange={(e) => setNewPlayerName(e.target.value)}
                    placeholder="Enter player name..."
                    className="flex-1 px-4 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                    maxLength={15}
                  />
                  <button
                    type="submit"
                    disabled={!newPlayerName.trim() || players.length >= 15}
                    className="bg-amber-100 text-amber-700 p-2 rounded-xl hover:bg-amber-200 transition-colors disabled:opacity-50"
                  >
                    <UserPlus className="w-6 h-6" />
                  </button>
                </form>

                <ul className="space-y-2">
                  <AnimatePresence>
                    {players.map((player, index) => (
                      <motion.li
                        key={index + player}
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="flex items-center justify-between bg-slate-50 px-4 py-3 rounded-xl"
                      >
                        <span className="font-medium">{player}</span>
                        <button
                          onClick={() => removePlayer(index)}
                          disabled={players.length <= 3}
                          className="text-slate-400 hover:text-red-500 transition-colors disabled:opacity-30"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </motion.li>
                    ))}
                  </AnimatePresence>
                </ul>
                
                {players.length < 3 && (
                  <p className="text-sm text-red-500 mt-4 text-center">
                    Minimum 3 players required!
                  </p>
                )}
              </div>

              <div className="bg-white p-6 rounded-2xl shadow-sm border border-amber-100">
                <h2 className="text-lg font-semibold mb-4 flex items-center gap-2 text-amber-900">
                  <BookOpen className="w-5 h-5" />
                  Select Categories
                </h2>
                <div className="flex flex-wrap gap-2">
                  {categories.map(cat => {
                    const isSelected = selectedCategories.includes(cat.name);
                    return (
                      <button
                        key={cat.name}
                        onClick={() => toggleCategory(cat.name)}
                        className={`px-4 py-2 rounded-xl text-sm font-medium transition-all flex items-center gap-2 border ${
                          isSelected 
                            ? 'bg-amber-100 border-amber-300 text-amber-800' 
                            : 'bg-slate-50 border-slate-200 text-slate-500 hover:bg-slate-100'
                        }`}
                      >
                        {isSelected && <Check className="w-4 h-4" />}
                        {cat.name}
                      </button>
                    );
                  })}
                </div>
              </div>

              <button
                onClick={startGame}
                disabled={players.length < 3 || selectedCategories.length === 0}
                className="w-full bg-amber-500 text-white py-4 rounded-2xl font-bold text-lg shadow-lg shadow-amber-500/30 hover:bg-amber-600 active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:active:scale-100"
              >
                <Play className="w-6 h-6 fill-current" />
                Start Game
              </button>
            </motion.div>
          )}

          {gameState === 'reveal' && (
            <motion.div
              key="reveal"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              className="flex flex-col items-center justify-center min-h-[60vh] space-y-8"
            >
              <div className="text-center space-y-2">
                <p className="text-slate-500 font-medium uppercase tracking-widest text-sm">
                  Pass the device to
                </p>
                <h2 className="text-4xl font-black text-amber-900">
                  {players[revealIndex]}
                </h2>
              </div>

              <div className="w-full max-w-sm aspect-square relative perspective-1000">
                <motion.div
                  className="w-full h-full relative preserve-3d cursor-pointer"
                  animate={{ rotateY: isRevealed ? 180 : 0 }}
                  transition={{ type: "spring", stiffness: 260, damping: 20 }}
                  onClick={() => setIsRevealed(!isRevealed)}
                >
                  {/* Front of card */}
                  <div className="absolute inset-0 backface-hidden bg-white rounded-3xl shadow-xl border-2 border-amber-100 flex flex-col items-center justify-center p-8 text-center">
                    <Eye className="w-16 h-16 text-amber-300 mb-4" />
                    <p className="text-lg font-medium text-slate-600">
                      Tap to reveal secret
                    </p>
                    <p className="text-sm text-slate-400 mt-2">
                      (Don't let anyone else see!)
                    </p>
                  </div>

                  {/* Back of card */}
                  <div className="absolute inset-0 backface-hidden bg-slate-900 text-white rounded-3xl shadow-xl flex flex-col items-center justify-center p-8 text-center [transform:rotateY(180deg)]">
                    {revealIndex === imposterIndex ? (
                      <div className="space-y-4">
                        <ShieldAlert className="w-20 h-20 text-red-500 mx-auto animate-pulse" />
                        <h3 className="text-3xl font-black text-red-500">You are the IMPOSTER!</h3>
                        <p className="text-slate-300">
                          Try to blend in and guess the word. Don't get caught!
                        </p>
                        <div className="mt-4 p-3 bg-slate-800 rounded-xl border border-slate-700">
                          <p className="text-sm text-slate-400 mb-1">Category</p>
                          <p className="font-bold text-amber-400">{currentCategory}</p>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="p-4 bg-slate-800 rounded-2xl border border-slate-700 w-full">
                          <p className="text-sm text-slate-400 mb-1">Category</p>
                          <p className="font-bold text-amber-400">{currentCategory}</p>
                        </div>
                        <div className="p-4 bg-slate-800 rounded-2xl border border-slate-700 w-full">
                          <p className="text-sm text-slate-400 mb-1">Secret Word</p>
                          <p className="text-2xl font-black text-emerald-400">{currentWord}</p>
                        </div>
                        <p className="text-sm text-slate-400 mt-4">
                          Find out who the Imposter is!
                        </p>
                      </div>
                    )}
                  </div>
                </motion.div>
              </div>

              <AnimatePresence>
                {isRevealed && (
                  <motion.button
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 20 }}
                    onClick={nextReveal}
                    className="bg-slate-900 text-white px-8 py-4 rounded-full font-bold text-lg flex items-center gap-2 hover:bg-slate-800 active:scale-95 transition-all shadow-lg"
                  >
                    {revealIndex < players.length - 1 ? 'Next Player' : 'Start Discussion'}
                    <ChevronRight className="w-5 h-5" />
                  </motion.button>
                )}
              </AnimatePresence>
            </motion.div>
          )}

          {gameState === 'discuss' && (
            <motion.div
              key="discuss"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              <div className="bg-white p-8 rounded-3xl shadow-sm border border-amber-100 text-center">
                <Timer className="w-12 h-12 text-amber-500 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-slate-800 mb-2">Discussion Time!</h2>
                <p className="text-slate-500 mb-6">
                  Ask questions to each other and find the Imposter.
                </p>
                
                <div className="text-6xl font-black text-amber-600 font-mono mb-8 tracking-tighter">
                  {formatTime(timeLeft)}
                </div>

                <div className="flex justify-center gap-4">
                  <button
                    onClick={() => setIsTimerRunning(!isTimerRunning)}
                    className="px-6 py-3 rounded-xl font-bold bg-slate-100 text-slate-700 hover:bg-slate-200 active:scale-95 transition-all"
                  >
                    {isTimerRunning ? 'Pause' : 'Resume'}
                  </button>
                  <button
                    onClick={() => setGameState('result')}
                    className="px-6 py-3 rounded-xl font-bold bg-amber-500 text-white hover:bg-amber-600 active:scale-95 transition-all shadow-md shadow-amber-500/20"
                  >
                    Vote Now
                  </button>
                </div>
              </div>

              <div className="bg-white p-6 rounded-3xl shadow-sm border border-amber-100">
                <h3 className="font-bold text-slate-800 mb-4">Players:</h3>
                <div className="flex flex-wrap gap-2">
                  {players.map((p, i) => (
                    <span key={i} className="px-4 py-2 bg-slate-50 rounded-lg text-sm font-medium border border-slate-100">
                      {p}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {gameState === 'result' && (
            <motion.div
              key="result"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-6 text-center pt-8"
            >
              <Trophy className="w-20 h-20 text-amber-500 mx-auto mb-6" />
              
              <div className="space-y-2">
                <h2 className="text-2xl font-bold text-slate-800">The Imposter was...</h2>
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", delay: 0.5 }}
                  className="text-5xl font-black text-red-500 py-4"
                >
                  {players[imposterIndex]}
                </motion.div>
              </div>

              <div className="bg-white p-6 rounded-3xl shadow-sm border border-amber-100 mt-8 space-y-4">
                <div>
                  <p className="text-sm text-slate-400 mb-1">Secret Word</p>
                  <p className="text-2xl font-bold text-emerald-500">{currentWord}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-400 mb-1">Category</p>
                  <p className="font-medium text-slate-700">{currentCategory}</p>
                </div>
              </div>

              <button
                onClick={resetGame}
                className="w-full mt-8 bg-slate-900 text-white py-4 rounded-2xl font-bold text-lg hover:bg-slate-800 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-5 h-5" />
                Play Again
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
